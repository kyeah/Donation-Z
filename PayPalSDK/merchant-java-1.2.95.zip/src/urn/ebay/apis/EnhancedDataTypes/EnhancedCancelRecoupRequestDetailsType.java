package urn.ebay.apis.EnhancedDataTypes;
import com.paypal.core.SDKUtil;

/**
 * 
 */
public class EnhancedCancelRecoupRequestDetailsType{


	

	/**
	 * Default Constructor
	 */
	public EnhancedCancelRecoupRequestDetailsType (){
	}	



	public String toXMLString() {
		StringBuilder sb = new StringBuilder();
		return sb.toString();
	}


}