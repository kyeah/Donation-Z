package urn.ebay.apis.EnhancedDataTypes;
import com.paypal.core.SDKUtil;

/**
 * 
 */
public class EnhancedInitiateRecoupRequestDetailsType{


	

	/**
	 * Default Constructor
	 */
	public EnhancedInitiateRecoupRequestDetailsType (){
	}	



	public String toXMLString() {
		StringBuilder sb = new StringBuilder();
		return sb.toString();
	}


}