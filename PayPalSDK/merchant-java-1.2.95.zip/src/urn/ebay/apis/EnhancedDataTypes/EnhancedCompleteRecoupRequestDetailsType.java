package urn.ebay.apis.EnhancedDataTypes;
import com.paypal.core.SDKUtil;

/**
 * 
 */
public class EnhancedCompleteRecoupRequestDetailsType{


	

	/**
	 * Default Constructor
	 */
	public EnhancedCompleteRecoupRequestDetailsType (){
	}	



	public String toXMLString() {
		StringBuilder sb = new StringBuilder();
		return sb.toString();
	}


}