PayPal Java AdaptiveAccounts API sample using the sdk
============================================

To build and run the adaptiveaccounts-sample:
------------------------------------
* 	update the sdk_config.properties in the adaptiveaccounts-sample/WebContent/WEB-INf/ directory with your API credentials.
*	simply run ant in the adaptiveaccounts-sample directory - it would rebuild the SDK if the sdk jar file doesn't exist already.
*	copy the dist/adaptiveaccounts-sample.war into your tomcat/webapps directory
*	start your tomcat if it's not already running
*	access http://<your-server-host:port>/adaptiveaccounts-sample/ in your browser to play with the test pages.

